No specific requirements as such - Just requires cascade.xml file and the dartboard images.
Run from terminal with image name as input.